#include <stdio.h>

int main() {
    float m2, m1, potencia;
    float soma = 0;
    for (int i = 38, j = 1; i > 1 ; i--, j++) {
        potencia = j;
        m1 = i - 1;
        m2 = i;
        soma += ((m1 * m2) / potencia);
        if (i > 2) {
            printf("(%.0f*%.0f) / %.0f + \n",m1,m2,potencia);
        } else {
            printf("(%.0f*%.0f) / %.0f = %.2f",m1,m2,potencia,soma);
        }
    }
}