#include <stdio.h>
#include <stdlib.h>

int main() {
    int *idades = NULL, continuar, count = 0, idade, media, total;
    
        //loop principal
        while(1) {
            printf("Qual sua idade?\n");
            scanf("%d", &idade);
            
            int *temp = realloc(idades, (count + 1) * sizeof(int));
            idades = temp;
            idades[count] = idade;
            count++;
            
            // loop inserir mais idade
            while (1) {
                printf("Deseja inserir mais uma idade?\n[1] Continuar\n[2] Finalizar\n");
                scanf("%d", &continuar);
            if (continuar == 1 || continuar == 2){
                break;
            } else {
                printf("Opção inválida.\n");
            } 
        } // loop mais idades
        if (continuar == 2) {
            printf("Finalizando.\n");
            break;
        }
    } // loop principal
            
    for (int i = 0; i < count; i++) {
        total += idades[i];
    }

    media = total / count;
    if (media <= 25) {
        printf("A turma é jovem. Tem média de %d anos de idade.", media);
    } else if (media > 25 && media < 60) {
        printf("A turma é adulta. Tem média de %d anos de idade.", media);
    } else {
        printf("A turma é idosa. Tem média de %d anos de idade.", media);
    }

    free(idades);
    return 0;
}