#include <stdio.h>

int main() {
    int numbers[10], pares[10], impares[10], soma = 0, count_pares = 0, count_impares = 0;
    for (int i = 0; i < 10; i++) {
        printf("Digite um número: ");
        scanf("%d", &numbers[i]);
        soma += numbers[i];
        if (numbers[i] % 2 == 0) {
            pares[count_pares] = numbers[i];
            count_pares++;
        } else {
            impares[count_impares] = numbers[i];
            count_impares++;
        }
    }
    printf("NUMEROS PARES:\n");
    for (int j = 0; j < count_pares; j++) {
        printf("%d \n", pares[j]);
    }
    
    printf("NUMEROS IMPARES:\n");
    for (int j = 0; j < count_impares; j++) {
        printf("%d \n", impares[j]);
    }
    
    printf("soma de todos os números: %d", soma);
}