#include <stdio.h>

int main() {
    
    int n1, n2, temp;
    printf("Digite um número inteiro: ");
    scanf("%d", &n1);
    printf("Digite outro número inteiro: ");
    scanf("%d", &n2);
    
    if (n1 > n2){
        temp = n1;
        n1 = n2;
        n2 = temp;
    }
    
    for (int i = n1 + 1 ; i < n2 ; i++) {
        printf("%d\n", i);
    }
    
    return 0;
}