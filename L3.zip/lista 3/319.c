#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, qtddivisiveis, cprimos = 0, calculos;
    
    // verifica se usuario inseriu número valido
    while (1){
        printf("Digite um número: ");
        scanf("%d", &n);
        if(n > 1) {
            break;
        } else {
            printf("Número inválido. O número deve ser maior que 1.");
        }
    }
    
    // alocar espaço
    int *conjuntoprimos = (int *)malloc(n * sizeof(int));
    
    // vai de 2 até n e verifica se é primo
    for (int i = 1; i <= n; i++) {
        qtddivisiveis = 0;
        printf("===\nCalculo do número %d\n", i);
        
        // verifica quantos divisores o número possui
        for (int j = 1; j <= i; j++) {
            calculos++; // contagem de calculos totais
            if (i % j == 0) {
                qtddivisiveis++;
            }
        }
        
        printf("quantidade divisiveis: %d\n", qtddivisiveis);
        if (qtddivisiveis == 2) {
           conjuntoprimos[cprimos] = i;
           cprimos++;
        }
    }
    printf("========\nCálculos totais: %d\n", calculos);
    printf("Entre 1 e %d, os números primos são:\n", n);
    for (int i = 0; i < cprimos; i++){
        printf("%d\n", conjuntoprimos[i]);
    }
    
    // libera memoria previamente alocada
    free(conjuntoprimos);
    
    return 0;
}