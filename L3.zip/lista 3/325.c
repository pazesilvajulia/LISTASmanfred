#include <stdio.h>
#include <stdlib.h>

int main() {
    int votos1 = 0, votos2 = 0, votos3 = 0;
    int voto, eleitores;
    printf("======== URNA ELETRÔNICA ========\n\n");
    while (1) {    
        printf("Número de eleitores: ");
        scanf("%d", &eleitores);
    if (eleitores < 1) {
        printf("Número inválido, tente novamente.\n");
    } else {
        break;
        }
    }
    
    printf("[1] - BOLSONARO\n[2] - LULA\n[3] - DONALD TRUMP\n");

    
    for (int i = 0; i < eleitores; i++) {
        while (1) {    
            printf("Voto do eleitor %d:\n", i+1);
            scanf("%d", &voto);
            if (voto == 1) {
                votos1++;
                break;
            } else if (voto == 2) {
                votos2++;
                break;
            } else if (voto == 3) {
                votos3++;
                break;
            } else {
                printf("Voto inválido.\n");
            }
        }
    }
    
    float perc1 = (votos1 * 100.00) / eleitores;
    float perc2 = (votos2 * 100.00) / eleitores;
    float perc3 = (votos3 * 100.00) / eleitores;
    
    printf("FIM DA VOTAÇÃO\n\n");
    printf("RESULTADOS:\n\n");
    printf("Bolsonaro - %.2f%% (%d votos válidos)\n", perc1, votos1);
    printf("Lula - %.2f%% (%d votos válidos)\n", perc2, votos2);
    printf("Donald Trump - %.2f%% (%d votos válidos)\n", perc3, votos3);
    
    return 0;
}