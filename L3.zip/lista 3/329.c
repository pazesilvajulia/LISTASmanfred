#include <stdio.h>
#include <stdlib.h>

int main() {
    
    int clube, procedencia, fan1=0, fan2=0, fan3=0, fan4=0, fan5=0, outRJfla=0, n=0, c;
    float salario, salarioFla=0, salarioFlu=0;
    
    while (1) {
        // loop seleçao time 
        while(1) { 
            n++;
            printf("SELECIONE SEU CLUBE:\n[1] Flamengo\n[2] Vasco\n[3] Botafogo\n[4] Fluminense\n[5] Outros\n");
            scanf("%d", &clube);
            if (clube > 0 && clube < 6) {
                if (clube == 1) {
                    fan1++;
                } else if (clube == 2) {
                    fan2++;
                } else if (clube == 3) {
                    fan3++;
                } else if (clube == 4) {
                    fan4++;
                } else if (clube == 5) {
                    fan5++;
                }
                break;
            } else {
                printf("Opção inválida.\n");
            }
        }
        
        // loop salario
        while(1) {    
            printf("INFORME SEU SALÁRIO: R$");
            scanf("%f", &salario);
            if (salario >= 0) {
                break;
            } else {
                printf("Opção inválida.\n");
            }
        }
        
        if (clube == 1) {
            salarioFla += salario;
        } else if (clube == 4) {
            salarioFlu += salario;
        }
        
        
        // procedencia 
        while(1) {   
            printf("CIDADE DE ORIGEM:\n[1] Rio de Janeiro\n[2] Outros\n");
            scanf("%d", &procedencia);
            if (procedencia > 0 && procedencia < 3) {
                break;
            } else {
                printf("Opção inválida.\n");
            }
        }
        
        if (clube == 1 && procedencia == 2) {
            outRJfla++;
        }
    
        printf("==================\n");
        while(1) {
            printf("[1] Adicionar mais torcedores\n[2] Finalizar\n");
            scanf("%d", &c);
            if (c == 2 || c == 1) {
                break;
            } else {
                printf("Opção inválida.\n");
            }
        }
        if (c == 2) {
            printf("Programa finalizado.\n\n");
            break;
        }
    }
    printf("Foram entrevistados %d pessoas:\n\n", n);
    printf("===== TORCEDORES =====\n");
    printf("Flamengo: %d\nVasco: %d\nBotafogo: %d\nFluminense: %d\nOutros: %d\n", fan1, fan2, fan3, fan4, fan5);
    printf("=== MÉDIA SALARIAL ===\n");
    printf("Flamengo:   ");
    if (fan1 > 0) {
        printf("R$%.2f\n", (salarioFla / fan1));
    } else {
        printf("Nenhum torcedor do Flamengo entrevistado.\n");
    }
    printf("Fluminense: ");
    if (fan4 > 0) {
        printf("R$%.2f\n", salarioFlu / fan4);
    } else {
        printf("Nenhum torcedor do Fluminense entrevistado.\n");
    }
    printf("Um total de %d torcedores do Flamengo moram fora do RJ\n", outRJfla);
    
    return 0;
}