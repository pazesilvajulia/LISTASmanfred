#include <stdio.h>

int main() {
    
    int numbers[10], temp, nmaior, nmenor;
    printf("DIGITE 10 NÚMEROS:\n");
    for (int i = 0 ; i < 10 ; i++) {
        printf("Digite o %dº número: \n", i+1);
        scanf("%d", &numbers[i]);
    }
    
    for (int i = 0; i < 10; i++){
        for (int j = 0; j < 10 - i - 1 ;j++){
            if(numbers[j] > numbers[j + 1]) {
                temp = numbers[j];
                numbers[j] = numbers[j + 1];
                numbers[j + 1] = temp;
            }
        }
    }
    
    nmaior = numbers[9];
    nmenor = numbers[0];
    
    printf("A diferença entre o maior (%d) e o menor (%d) número digitado é de %d", nmaior, nmenor, (nmaior - nmenor));
    
    return 0;
}