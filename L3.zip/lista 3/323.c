#include <stdio.h>
#include <stdlib.h>

int main() {
    int vel;
    while (1) {
        while (1) {
        printf("Digite a velocidade atual (km/h): ");
        scanf("%d", &vel);
        if (vel < 0) {
            printf("Velocidade não pode ser negativa. Tente novamente.\n");
        } else {
            break;
    }
    }
    
    if (vel == 0) {
        printf("Veículo parado. Finalizando programa.\n");
        break;
    } else {
        printf("==== MARCHA: ");
        if (vel < 30){
            printf("1ª\n");
        } else if (vel < 40) {
            printf("2ª\n");
        } else if (vel < 60) {
            printf("3ª\n");
        } else if (vel < 80) {
            printf("4ª\n");
        } else {
            printf("5ª\n");
        }
    }
    }
    return 0;
}