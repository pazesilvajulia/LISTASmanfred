#include <stdio.h>
#include <stdlib.h>

int main() {
    int c = 1, total1 = 0, total2 = 0, total3= 0, resposta;
    float fat1, fat2, fat3, fattotal;
    int *picole1 = (int*)calloc(1, sizeof(int) * c);
    int *picole2 = (int*)calloc(1, sizeof(int) * c);
    int *picole3 = (int*)calloc(1, sizeof(int) * c);
    
    printf("== SORVETERIA ==\n");
    printf("PICOLÉ DE FRUTA\n===  R$1,00\n");
    printf("PICOLÉ DE CREME\n===  R$1,20\n");
    printf("PICOLÉ PREMIUM\n===  R$2,50\n");
    
    while (1) {
        printf("=-=-=-=-= Dia %d =-=-=-=-=\n", c);
        // picole 1
        while (1) {    
            printf("Quantidade picolés de fruta vendidos:\n");
            scanf("%d", &resposta);
        if (resposta >= 0) {
            total1 += resposta;
            picole1[c-1] = resposta; 
            break;
        } else {
            printf("Valor inválido.\n");
            }
        }
        // picole 2
        while (1) {    
            printf("Quantidade picolés de creme vendidos:\n");
            scanf("%d", &resposta);
        if (resposta >= 0) {
            total2 += resposta;
            picole2[c-1] = resposta; 
            break;
        } else {
            printf("Valor inválido.\n");
            }
        }
         // picole 3
        while (1) {    
            printf("Quantidade picolés premium vendidos:\n");
            scanf("%d", &resposta);
        if (resposta >= 0) {
            total3 += resposta;
            picole3[c-1] = resposta; 
            break;
        } else {
            printf("Valor inválido.\n");
            }
        }
        // adicionar mais ou finalizar
        while(1) {
            printf("[1] Inserir dados de mais dias\n[2] Finalizar programa\n");
            scanf("%d", &resposta);
            if (resposta == 1 || resposta == 2) {
                break;
            }
        }
        
        if (resposta == 1) {
            c++;
            picole1 = (int*)realloc(picole1, sizeof(int) * c);
            picole2 = (int*)realloc(picole2, sizeof(int) * c);
            picole3 = (int*)realloc(picole3, sizeof(int) * c);
        } else if (resposta == 2) {
            printf("Finalizando programa.\n");
            break;
        }
}

fat1 = total1 * 1;
fat2 = total2 * 1.2;
fat3 = total3 * 2.5;
fattotal = fat1 + fat2 + fat3;

printf("=-=-=-=-= RELATÓRIO DE VENDAS =-=-=-=-=\n");
printf("Total picolés vendidos no período: %d\n", (total1 + total2 + total3));
printf("Faturamento total: R$%.2f\n", fattotal);
printf("Total de picolés de fruta: %d\n - Faturamento: R$%.2f\n", total1, fat1);
printf("Total de picolés de creme: %d\n - Faturamento: R$%.2f\n", total2, fat2);
printf("Total de picolés premium: %d\n - Faturamento: R$%.2f\n", total3, fat3);

for (int i = 0; i < c; i++) {
    
    printf("========== Dia %d\n", i+1);
    printf("Picolés de fruta: %d\n- Faturamento: R$%.2f\n", picole1[i], (float)picole1[i]);
    printf("Picolés de creme: %d\n- Faturamento: R$%.2f\n", picole2[i], picole2[i] * 1.2);
    printf("Picolés premium: %d\n- Faturamento: R$%.2f\n", picole3[i], picole3[i] * 2.5);
}

printf("\n\n\n");
printf("O picolé com maior faturamento foi o ");
if (fat1 > fat2 && fat1 > fat3) {
    printf("de Fruta com um total de R$%.2f, representando %.2f%% do faturamento total", fat1, ((fat1 * 100) / fattotal));
} else if (fat2 > fat1 && fat2 > fat3) {
    printf("de Creme com um total de R$%.2f, representando %.2f%% do faturamento total", fat2, ((fat2 * 100) / fattotal));
} else if (fat3 > fat2 && fat3 > fat1) {
    printf("Premium com um total de R$%.2f\nRepresenta %.2f%% do faturamento total.\n", fat3, ((fat3 * 100) / fattotal));
}

printf("O faturamento da sorveteria no período foi de R$%.2f", fattotal);

free(picole1);
free(picole2);
free(picole3);

return 0;
}