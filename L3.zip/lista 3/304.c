#include <stdio.h>

int main() {
    int qtd;
    float somatorio = 0, nota;
    
    printf("Quantos alunos tem na turma?\n");
    scanf("%d", &qtd);
    for (int i = 0 ; i < qtd ; i++) {
        printf("Digite a %dº nota: \n", i+1);
        scanf("%f", &nota);
        somatorio = somatorio + nota;
    }
    
    printf("média da turma: %.2f\nquantidade de alunos: %d\n", (somatorio / qtd), qtd);
    
    return 0;
}