#include <stdio.h>
#include <stdlib.h>

int main() {
    
 int nAlunos, sexo, idades = 0, input, h = 0, m = 0;
 float alturahomens, alturamulheres, a, maiorA = 0, menorA = 1000;
 printf("Quantidade de alunos:\n");
 scanf("%d", &nAlunos);
 
 for (int i = 0; i < nAlunos; i++) {
    while (1) {
        printf("Sexo aluno nº%d - [1] Homem  [2] Mulher  ", i+1);
        scanf("%d", &sexo);
        if (sexo == 1 || sexo == 2) {
            break;
        } else {
            printf("Opção inválida, tente novamente.\n");
        }
     }
     
     // altura
     while (1) {
     printf("Altura aluno %d:\n", i + 1);
     scanf("%f", &a);
     if (a > 0 && a < 3) {
         break;
    } else {
         printf("Altura inválida. Insira a altura em METROS.\n");
        }
    }
    
// idade
     while (1) {
         printf("Idade do aluno: \n");
         scanf("%d", &input);
         if (input > 0 && input < 120) {
             idades += input;
             break;
         } else {
             printf("Idade inválida.\n");
         }
     }    
    
    
if (sexo == 1) {
    h++;
    alturahomens += a;
} else if (sexo == 2) {
    m++;
    alturamulheres += a;
}
if (a > maiorA) {
    maiorA = a;
} 
if (a < menorA) {
    menorA = a;
}

} // for loop
printf("==================\n");
printf("Maior altura:           %.2fm\n", maiorA);
printf("Menor altura:           %.2fm\n", menorA);
printf("Média altura mulheres:  %.2fm\n", alturamulheres / m);
printf("Média altura homens:    %.2fm\n", alturahomens / h);
printf("Média idade turma:      %d anos\n", (idades / nAlunos));

}