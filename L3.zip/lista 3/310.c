#include <stdio.h>

int main() {
    int base, potencia, temp;
    printf("Vamos fazer uma potência!\n");
   
    printf("Digite a base: ");
    scanf("%d", &base);
   
    printf("Digite a potencia: ");
    scanf("%d", &potencia);
    
    temp = base;
    for (int i = 0; i < potencia - 1; i++) {
        temp = temp * base;
    }
    printf("resultado: %d", temp);
}