#include <stdio.h>

int main() {
    int num, numinvertido;
    while (1) {
       printf("Digite um número inteiro positivo: ");
        scanf("%d", &num);
        if (num > 0) {
            break;
        } else {
            printf("ops, número não aceito. tente de novo.\n");
        }
    }
    printf("boa corno\n");
    printf("teu número invertido é 1/%d", num);
}