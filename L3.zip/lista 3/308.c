#include <stdio.h>

int main() {
    int pop1 = 80000, pop2 = 200000; 
    float cresc1 = 1.03, cresc2 = 1.015;
        for (int i = 0; pop1 <= pop2; i++) {
            pop1 = pop1 * cresc1;
            pop2 = pop2 * cresc2;
            printf("Ano %d: pop1: %d e pop2: %d\n", i, pop1, pop2);
        }
    printf("Passou.");
}