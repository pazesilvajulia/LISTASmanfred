#include <stdio.h>

int main() {
    int continuar;
    
    while (1){
        int c = 0;
        for (int i = 100; i <= 200; i++) {
            if (i % 2 == 0) {
                printf("%d + %d = %d\n", c, i, c + i);
                c = c + i;
            }
        } 
        
        printf("A soma dos pares entre 100 e 200 é: %d\n", c);
        
        while (1) {
            printf("Gostaria de ver o resultado novamente?\n[1] - Sim\n[2] - Não\n");
            scanf("%d", &continuar);
            if (continuar == 1 || continuar == 2) {
                break;
            } else {
            printf("Resposta inválida. tente novamente.\n");
            }
        }
        if (continuar == 2) {
            printf("finalizando.");
            break;
        }
    }
}