#include <stdio.h>
#include <stdlib.h>

int main() {
    int codigo;
    float fixo, salario, vendas;

while(1) {    
    printf("Código do vendedor:\n");
    scanf("%d", &codigo);
    
    printf("Salário Fixo: R$");
    scanf("%f", &fixo);
    
    printf("Valor total de vendas: R$");
    scanf("%f", &vendas);
    
    if (vendas >= 100000) {
        salario = (fixo + (0.1 * vendas));
    } else {
        salario = (fixo + (0.06 * vendas));
    }
    
printf("Salário funcionário nº%d: R$%.2f\n", codigo, salario);

printf("[1] Adicionar outro funcionário\n[2] Finalizar\n");
scanf("%d", &codigo);
if (codigo == 2) {
    break;
}
} // main loop
}