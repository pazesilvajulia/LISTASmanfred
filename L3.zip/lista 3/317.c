#include <stdio.h>

int main() {
    int n, total = 1;
    printf("Número para ver o fatorial: ");
    scanf("%d", &n);
    
    for (int i = n; i > 1; i--) {
        printf("%d x ", i, total * i);
        total *= i;
    }
    
    printf("x 1 = %d", total);
    
    return 0;
}
