#include <stdio.h>

int main() {
    int numcds;
    float total = 0;
    printf("Quantidade de CDs: ");
    scanf("%d", &numcds);
    float custocds[numcds];
    for (int i = 0; i < numcds; i++) {
        printf("Custo do CD nº%d: R$", i + 1);
        scanf("%f", &custocds[i]);
        total += custocds[i];
    }
    printf("=================\n");
    printf("Quantidade CDs: %d\n", numcds);
    printf("Custo médio: R$%.2f\n", (total / numcds));
    printf("Total investido: R$%.2f", total);
    
    return 0;
    
}

