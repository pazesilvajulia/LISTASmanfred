#include <stdlib.h>
#include <stdio.h>

int main() {
    float ticket1 = 30, ticket2 = 15, ticket3 = 20;
    int total1 = 50, total2 = 50, total3 = 50, ingressos, filme, c;
    while(1) {
        while(1) {    
            printf("Selecione seu filme:\n");
            printf("[1] Vingadores\n    LEGENDADO 3D - R$%.2f\n[2] A Culpa é das Estrelas\n    DUBLADO 2D   - R$%.2f\n[3] Titanic\n    LEGENDADO    - R$%.2f\n", ticket1, ticket2, ticket3);
            scanf("%d", &filme);
            if (filme > 0 && filme < 4) {
                break;
            } else {
                printf("ESCOLHA INVÁLIDA.\n");
            }
        }    
        if (filme == 1) {
            
            while (1) {
                printf("SELEÇÃO: Vingadores\n");
                printf("Selecione o número de ingressos (disponíveis: %d)\n", total1);
                scanf("%d", &ingressos);
                if (ingressos <= total1) {
                    total1 -= ingressos;
                    break;
                } else {
                    printf("ERRO. Limite de ingressos disponíveis atingido.\n");
                }
            }
            
        } else if (filme == 2) {
            
            while (1) {
                printf("SELEÇÃO: A Culpa é das Estrelas\n");
                printf("Selecione o número de ingressos (disponíveis: %d)\n", total2);
                scanf("%d", &ingressos);
                if (ingressos <= total2) {
                    total2 -= ingressos;
                    break;
                } else {
                    printf("ERRO. Limite de ingressos disponíveis atingido.\n");
                }
            }
            
        } else if (filme == 3) {
            
            while (1) {
                printf("SELEÇÃO: Titanic\n");
                printf("Selecione o número de ingressos (disponíveis: %d)\n", total3);
                scanf("%d", &ingressos);
                if (ingressos <= total3) {
                    total3 -= ingressos;
                    break;
                } else {
                    printf("ERRO. Limite de ingressos disponíveis atingido.\n");
                }
            }   
    }
    while (1) {
        printf("Deseja continuar?\n");
        printf("[1] Continuar comprando\n[2] Finalizar e ir para pagamento\n");
        scanf("%d", &c);
        if (c > 0 && c < 3) {
            break;
        } else {
            printf("opção inválida.\n");
        }
    }
    
    if (c == 2) {
        printf("Seleção finalizada. Indo para o carrinho...\n");
        break;
    }
}
printf("=== CARRINHO ===\n");
printf("Total de ingressos comprados sessão (Vingadores): %d\n", (50 - total1));
printf("Total: R$%.2f\n", (50 - total1) * ticket1);
printf("Total de ingressos comprados sessão (A Culpa é das Estrelas): %d\n", (50 - total2));
printf("Total: R$%.2f\n", (50 - total2) * ticket2);
printf("Total de ingressos comprados sessão (Titanic): %d\n", (50 - total3));
printf("Total: R$%.2f\n", (50 - total3) * ticket3);

}