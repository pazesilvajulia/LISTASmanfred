#include <stdio.h>
#include <stdlib.h>

int main() {
    int qtdturmas, *qtdalunos;
    
    // alocar a memória corretamente pois da outra forma deu erro
    qtdalunos = (int*) malloc(qtdturmas * sizeof(int));

    printf("Quantidade de turmas: ");
    scanf("%d", &qtdturmas);
    for (int i = 0; i < qtdturmas; i++) {
        while (1) {
            printf("Nº alunos turma nº%d: ", i + 1);
            scanf("%d", &qtdalunos[i]);
            if (qtdalunos[i] > 40 || qtdalunos[i] < 1) {
                printf("ERRO. São aceitas turmas com entre 1 e 40 alunos.\n");        
            } else {
                break;
            }
        }
    }
    for (int j = 0; j < qtdturmas; j++){
        printf("Turma %d: %d alunos\n", j+1, qtdalunos[j]);
    }

    return 0;
}