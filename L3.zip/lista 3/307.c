#include <stdio.h>

int main() {
    int num;
    printf("Número para gerar a tabuada: ");
    scanf("%d", &num);
    for (int i = 0; i < 10; i++) {
        printf("%d X %d = %d\n", i+1, num, (i+1) * num);
    }
    
    return 0;
}