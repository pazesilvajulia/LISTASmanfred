#include <stdio.h>

int main() {
    
    float dividendo, divisor;
    float soma = 0;
    for (int i = 0; i < 50; i++) {
        dividendo = (i + 1) + i;
        divisor = i + 1;
        soma = soma + (dividendo / divisor);
        if (i != 49) {
            printf("%.0f/%.0f + \n", dividendo, divisor);
        } else {
            printf("%.0f/%.0f = %.2f\n", dividendo, divisor, soma);
        }
    }
}