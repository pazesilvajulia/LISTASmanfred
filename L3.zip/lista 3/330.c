#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

int valor_letra (char c) {
    if (isalpha(c)) {
        return(tolower(c)) - 'a' + 1;
    } else {
        return 0;
    }
}

int calcular_numero (char nome[]) {
    int soma = 0;
    for (int i = 0; nome[i] != '\0'; i++) {
        soma += valor_letra(nome[i]);
    }
    return soma % 9;
}

int main() {
    char nome[100];
    printf("Digite seu nome completo (sem espaços)\n");
    scanf("%s", nome);

    int numero = calcular_numero(nome);

    printf("%d é seu número da sorte!", numero);

    return 0;
}