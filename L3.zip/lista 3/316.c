#include <stdio.h>

void fibonacci(int num) {
    if (num > 0) {printf("Termo nº1: 0\n");}
    if (num > 1) {printf("Termo nº2: 1\n");}
    
    int a = 0, b = 1, c;
    for (int i = 2; i < num; i++) {
        c = a + b;
        a = b;
        b = c;
        printf("Termo nº %d: %d\n", i+1, c);
        }
    }

int main() {
    int qtd;
    printf("GERADOR DE SEQUÊNCIA FIBONACCI\n");
    printf("==============================\n");
    printf("Quantidade de termos: \n");
    scanf("%d", &qtd);
    fibonacci(qtd);
}