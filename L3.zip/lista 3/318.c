#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, c = 0;
    printf("Digite um número: ");
    scanf("%d", &n);
    int *divisiveis = (int *)malloc(n * sizeof(int));
    
    for (int i = n; i > 0; i--) {
        if (n % i == 0) {
            divisiveis[c] = i;
            c++;
        }
    }
    
    if (c > 2) {
        printf("%d não é primo\n%d é divisível pelos seguintes números:\n", n, n );
        for (int i = 0; i < c; i++) {
            printf("%d\n", divisiveis[i]);
        }
    } else {
        printf("%d é número primo, pois só é divisível por ele mesmo e 1", n);
    }
}