#include <stdio.h>

int main() {
    int continuar;
    while (1) {
        int num;
        printf("Número para gerar a tabuada: ");
        scanf("%d", &num);
        for (int i = 10; i > 0; i--) {
            printf("%d X %d = %d\n", i, num, i * num);
        }
        while (1) {
            printf("Deseja continuar?\n");
            printf("[1] Continuar\n[2] Finalizar programa\n");
            scanf("%d", &continuar);
            if (continuar == 1 || continuar == 2){
                break;
            } else {
                printf("ESCOLHA INVÁLIDA.");
            }
        }
        if (continuar == 2){
            printf("Finalizando.");
            break;
        }
    }
    return 0;
}