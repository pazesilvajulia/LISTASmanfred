#include <stdio.h>
#include <stdlib.h>

int main() {
    while (1) {
    float distanciatotal, capacidadetanque, consumo, fuelleft, autonomia, n;
    int refuel, c;
    printf("Distância da viagem (km):\n");
    scanf("%f", &distanciatotal);
    printf("Capacidade do tanque (L):\n");
    scanf("%f", &capacidadetanque);
    printf("Consumo do veículo (km/L):\n");
    scanf("%f", &consumo);
    autonomia = capacidadetanque * consumo;
    
    printf("O veículo faz %.0fkm por tanque.\n", autonomia);
    
    n = (distanciatotal / autonomia);
    refuel = n;
    printf("Refuel = %d\n", refuel);
    if (distanciatotal == autonomia) {
        printf("A distância para o destino e a autonomia é exatamente a mesma.\n");
        return 0;
    }
    else if (refuel >= 1) {
        printf("Nº paradas para reabastecer: %d\n", refuel);
        fuelleft = (distanciatotal - autonomia * refuel) / consumo;
    } else {
        printf("Sem parada para reabastecer\n");
        fuelleft = (distanciatotal - autonomia) / consumo;
    }
    
    printf("%.1f litros foram consumidos\n", distanciatotal / consumo);
    
    printf("Restaram %.0f litros ao final da viagem.\n\n\n", fuelleft);
    while (1){
        printf("deseja repetir o programa?\n[1] sim\n[2] finalizar\n");
        scanf("%d", &c);
        if (c == 2) {
            break;
        } else if (c == 1) {
            printf("Recomeçando...\n");
            break;
        } else {
            printf("opção Inválida, tente novamente\n");
        }
    }
    if (c == 2){
        break;
    }
}
    return 0;
}