#include <stdio.h>

int main() {
  printf("Alo mundo");
  return 0;
}