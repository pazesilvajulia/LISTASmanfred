#include <stdio.h>

int main() {
    int num;
    printf("Insira um número: ");
    scanf("%d", &num);
    printf("O número inserido foi: %d", num);
  
  
  
  return 0;
}