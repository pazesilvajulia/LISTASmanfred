#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void ordenar(int *a, int *b, int *c) {
    int temp;
    if (*a > *b) {
        temp = *a;
        *a = *b;
        *b = temp;
    }
    if (*a > *c) {
        temp = *a;
        *a = *c;
        *c = temp;
    }
    if (*b > *c) {
        temp = *b;
        *b = *c;
        *c = temp;
    }
}
// ---------------------------- //
int a, b, c;

int main() {
    printf("Digite um número: ");
    scanf("%d", &a);
    printf("Digite um número: ");
    scanf("%d", &b);
    printf("Digite um número: ");
    scanf("%d", &c);
    ordenar(&a, &b, &c);
    printf("A: %d  B: %d  C: %d", a, b, c);
}