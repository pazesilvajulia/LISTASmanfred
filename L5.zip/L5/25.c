/* 25.	Faça um programa que leia o preço de 10 produtos e armazene em um vetor. Faça uma função para ler, outra para ordenar ( em ordem de preço ) e outra para mostrar os dados.(sem passagem de parâmetros) */

#include <stdio.h>

#define TAM 10

float precos[TAM];

// leitura
void ler() {
    for (int i = 0; i < TAM; i++) {
        printf("Digite o preço do produto %d: R$ ", i + 1);
        scanf("%f", &precos[i]);
    }
}

//  ordenar
void ordenar() {
    for (int i = 0; i < TAM - 1; i++) {
        for (int j = 0; j < TAM - i - 1; j++) {
            if (precos[j] > precos[j + 1]) {
                float temp = precos[j];
                precos[j] = precos[j + 1];
                precos[j + 1] = temp;
            }
        }
    }
}

// print
void mostrar() {
    printf("\nPreços em ordem crescente:\n");
    for (int i = 0; i < TAM; i++) {
        printf("Produto %d: R$ %.2f\n", i + 1, precos[i]);
    }
}

int main() {
    ler();        
    ordenar();    
    mostrar();    
    return 0;
}