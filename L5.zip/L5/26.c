#include <stdio.h>

int converterparasegundos(int h, int m, int s) {
    return (h * 3600) + (m * 60) + s;
}

int main() {
    int horas, minutos, segundos;

    printf("Digite as horas: ");
    scanf("%d", &horas);

    printf("Digite os minutos: ");
    scanf("%d", &minutos);

    printf("Digite os segundos: ");
    scanf("%d", &segundos);

    int total = converterparasegundos(horas, minutos, segundos);

    printf("Total em segundos: %d\n", total);

    return 0;
}