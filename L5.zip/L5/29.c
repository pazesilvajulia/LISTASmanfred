#include <stdio.h>

#define MAX 100

struct Tarefa {
    int empregado;
    int dia, mes, ano;
    int hInicio, mInicio, sInicio;
    int hFim, mFim, sFim;
};

int main() {
    struct Tarefa tarefas[MAX];
    int i = 0;

    printf("Cadastro de tarefas dos funcionários\n");
    printf("(Digite 0 ou número negativo para encerrar)\n");

    while (1) {
        printf("\nFuncionário #%d\n", i + 1);

        printf("Número do empregado: ");
        if (scanf("%d", &tarefas[i].empregado) != 1) break;

        if (tarefas[i].empregado <= 0) {
            break;
        }

        printf("Data (dd mm aaaa): ");
        if (scanf("%d %d %d", &tarefas[i].dia, &tarefas[i].mes, &tarefas[i].ano) != 3) break;

        printf("Hora de início (hh mm ss): ");
        if (scanf("%d %d %d", &tarefas[i].hInicio, &tarefas[i].mInicio, &tarefas[i].sInicio) != 3) break;

        printf("Hora de término (hh mm ss): ");
        if (scanf("%d %d %d", &tarefas[i].hFim, &tarefas[i].mFim, &tarefas[i].sFim) != 3) break;

        i++;

        if (i >= MAX) {
            printf("Número máximo de registros atingido!\n");
            break;
        }
    }

    printf("\n--- Tarefas registradas ---\n");

    for (int j = 0; j < i; j++) {
        printf("\nFuncionário: %d\n", tarefas[j].empregado);
        printf("Data: %02d/%02d/%04d\n", tarefas[j].dia, tarefas[j].mes, tarefas[j].ano);
        printf("Início: %02d:%02d:%02d\n", tarefas[j].hInicio, tarefas[j].mInicio, tarefas[j].sInicio);
        printf("Término: %02d:%02d:%02d\n", tarefas[j].hFim, tarefas[j].mFim, tarefas[j].sFim);
    }

    return 0;
}