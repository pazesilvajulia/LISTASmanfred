#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

/* 19.	Escreva uma função que receba  como argumentos o dia, o mês e o ano e retorne 1 se a data for válida  ou 0 se for uma data inválida. Utilize seu programa de consistência de data e converta-o em uma função de uma biblioteca própria. */

int isleapyear(int ano) {
    if ((ano % 400 == 0) || (ano % 4 == 0 && ano % 100 != 0)) {
        return 1;
    } else {
        return 0;
    }
}

int isvaliddate(int day, int month,int year) {
    
    if (year <= 0) return 0;
    
    if (month < 1 || month > 12) return 0;

    if (month == 2) {
        if (isleapyear(year)) {
            if (day < 1 || day > 29) return 0;  
        } else {
            if (day < 1 || day > 28) return 0;
        }
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
        if (day < 1 || day > 30) return 0; 
    } else {
        if (day < 1 || day > 31) return 0;
    }

    return 1;  // data válida
}

int main() {
    int dia, mes, ano;
    printf("Digite um dia (dd): ");
    scanf("%d", &dia);
    printf("Digite um mês (mm): ");
    scanf("%d", &mes);
    printf("Digite um ano (aaaa): ");
    scanf("%d", &ano);
    if (isvaliddate(dia, mes, ano)) {
        printf("Data válida!");
    } else {
        printf("Data inválida.");
    }
}