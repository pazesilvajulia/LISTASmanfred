#include <stdio.h>

void converterparahoraminseg(int totalseg, int *h, int *m, int *s) {
    *h = totalseg / 3600;
    *m = (totalseg % 3600) / 60;
    *s = totalseg % 60;
}

int main() {
    int totalsegundos;
    int horas, minutos, segundos;

    printf("Digite o total de segundos: ");
    scanf("%d", &totalsegundos);

    converterparahoraminseg(totalsegundos, &horas, &minutos, &segundos);

    printf("Resultado: %d hora(s), %d minuto(s), %d segundo(s)\n", horas, minutos, segundos);

    return 0;
}