#include <stdio.h>

void dectohex(int num) {
    char hex[100];  
    int i = 0;

    if (num == 0) {
        printf("0");
        return;
    }

    while (num > 0) {
        int resto = num % 16;

        if (resto < 10) {
            hex[i] = '0' + resto;       
        } else {
            hex[i] = 'a' + (resto - 10);
        }
        num = num / 16;
        i++;
    }

    for (int j = i - 1; j >= 0; j--) {
        printf("%c", hex[j]);
    }
}

int main() {
    int numero;
    printf("Digite um número decimal: ");
    scanf("%d", &numero);

    printf("Hexadecimal: ");
    dectohex(numero);
    printf("\n");

    return 0;
}