#include <stdio.h>


float minicial, mfinal;
int tempo;


void ler() {
    do {
        printf("Digite a massa inicial (g): ");
        scanf("%f", &minicial);
        if (minicial <= 0) {
            printf("valor invalido.\n");
        }
    } while (minicial <= 0);
}

void calcular() {
    mfinal = minicial;
    tempo = 0;

    while (mfinal >= 0.5) {
        mfinal /= 2.0;
        tempo += 50;
    }
}

void mostrar() {
    printf("\nMassa inicial: %.2f g\n", minicial);
    printf("Massa final: %.2f g\n", mfinal);
    printf("Tempo necessário: %d segundos\n", tempo);
}

int main() {
    ler();
    calcular();
    mostrar();
    return 0;
}