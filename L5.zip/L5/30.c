#include <stdio.h>

#define max 100

struct tarefa {
    int emp;
    int d, m, a;
    int hi, mi, si;
    int hf, mf, sf;
    int dur;
};

struct tarefa t[max];
int qtd = 0;

int tempo_seg(int h, int m, int s) {
    return h * 3600 + m * 60 + s;
}

void seg_tempo(int total, int *h, int *m, int *s) {
    *h = total / 3600;
    total %= 3600;
    *m = total / 60;
    *s = total % 60;
}

void ler() {
    while (1) {
        printf("\nempregado: ");
        scanf("%d", &t[qtd].emp);
        if (t[qtd].emp <= 0) break;

        printf("data (dd mm aaaa): ");
        scanf("%d %d %d", &t[qtd].d, &t[qtd].m, &t[qtd].a);

        printf("inicio (hh mm ss): ");
        scanf("%d %d %d", &t[qtd].hi, &t[qtd].mi, &t[qtd].si);

        printf("fim (hh mm ss): ");
        scanf("%d %d %d", &t[qtd].hf, &t[qtd].mf, &t[qtd].sf);

        qtd++;

        if (qtd >= max) break;
    }
}

void calc() {
    for (int i = 0; i < qtd; i++) {
        int ini = tempo_seg(t[i].hi, t[i].mi, t[i].si);
        int fim = tempo_seg(t[i].hf, t[i].mf, t[i].sf);
        t[i].dur = fim - ini;
    }
}

void mostrar() {
    int h, m, s;
    for (int i = 0; i < qtd; i++) {
        seg_tempo(t[i].dur, &h, &m, &s);
        printf("\nempregado %d -> duracao: %02d:%02d:%02d\n", t[i].emp, h, m, s);
    }
}

int main() {
    ler();
    calc();
    mostrar();
    return 0;
}