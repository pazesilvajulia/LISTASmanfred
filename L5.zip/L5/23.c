#include <stdio.h>

int isvalid(int num) {
    if (num > 0) {
        return 1;
    } else {
        return 0;
    }
}

int fat(int n) {
    int total = 1;
    for (int i = n; i > 1; i--) {
        printf("%d x ", i, total * i);
        total *= i;
        }
    printf("1 = %d", total);
    }

int main() {
    int n;
    do {
        printf("Número para ver o fatorial: ");
        scanf("%d", &n);
        if (!isvalid(n)) {
            printf("Opção inválida.\n");
        }
    } while (!isvalid(n));
    
    fat(n);
    
    return 0;
}