#include <stdio.h>

int power(int base, int potencia) {
    int valor;
    int temp = base;
    for (int i = 0; i < potencia - 1; i++) {
        temp = temp * base;
    }
    return temp;
}

void mostrar(int var) {
    printf("Resultado: %d", var);
}

int main() {
    int base, pot;
    printf("Base: ");
    scanf("%d", &base);
    printf("Potência: ");
    scanf("%d", &pot);
    int resultado = power(base, pot);
    mostrar(resultado);
}