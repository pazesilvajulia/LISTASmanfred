#include <stdio.h>
#include <stdlib.h>

int comparar(const void *a, const void *b) {
    int num1 = *(int*)a;  // (int*)a vai receber void*a e converter para um ponteiro de inteiro, que vai apontar justamente para um endereço que armazena número inteiro. void * a contém somente o endereço de a. ao usar *(int*)a, acessamos o valor dentro de a (o qual já temos o endereço E TAMBÉM sabemos que é um valor inteiro).
    int num2 = *(int*)b;
    return num1 - num2;
}

int main() {
    int vetor[10], maior;
    for (int i = 0; i < 10; i++) {
        printf("Digite um número (%d de 10): ", i+1);
        scanf("%d", &vetor[i]);
    }
    // qsort(array, tamanho, tamanho de cada item, diferença (+, - ou ==, faremos através de função comparar)). não precisamos passar os valores em comparar(), pois a função qsort já faz isso.
    qsort(vetor, 10, sizeof(int), comparar);
    
    printf("Vetor ordenado: \n");
    for (int j = 0; j < 10; j++) {
        printf("%d ", vetor[j]);
    }
}