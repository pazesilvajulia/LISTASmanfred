#include <stdio.h>
#include <stdlib.h>


int main() {
    int *num, c = 0, input;
    num = NULL;
    
    while(1) {
        c++; // aumentando a contagem
        // realloc para memoria
        int *temp = realloc(num, c * sizeof(int));
        num = temp;
        
        printf("Digite um número: \n");
        scanf("%d", &num[c-1]);
        
        while(1) {
            printf("[1] adicionar mais números  [2] finalizar\n");
            scanf("%d", &input);
            if (input == 2 || input == 1) {
                break;
            } else {
                printf("ERRO. ");
            }
        }
        if (input == 2) break;
    }
    // malloc para array dos numeros finais
    int *result = malloc(c * sizeof(int));
    
    for (int i = 0; i < c; i++) {
        result[i] = (num[i] - num[c - 1 - i]);
        printf("%d - %d = %d\n", num[i], num[c-1-i], result[i]);
    }
    
    free(num);
    free(result);
    return 0;
}