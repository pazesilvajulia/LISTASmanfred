#include <stdio.h>
#include <stdlib.h>

int main() {
    float notas[4], media = 0;
    for (int i = 0; i < 4; i++) {
        while (1) {
            printf("Insira a nota nº%d: ", i+1);
            scanf("%f", &notas[i]);
            if (notas[i] <= 10 && notas[i] >= 0) {
                break;
            } else {
                printf("Nota inválida.\n");
            }
        }
        media += notas[i];
    }
    if (media == 0) {
        printf("Média das notas: 0\n");
    } else {
        printf("Média das notas: %.1f", media / 4);
    }
}