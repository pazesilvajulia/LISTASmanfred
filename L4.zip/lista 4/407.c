#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

    int Persons[5][2];
    
    for (int i = 0; i < 5; i++) {
        printf("== CADASTRO Nº%d ==\n", i+1);
        while(1) {
            printf("Digite sua idade: \n");
            scanf("%d", &Persons[i][0]);
            if (Persons[i][0] > 0 && Persons[i][0] < 120) {
                break;
            } else {
                printf("Valor inválido.\n");
            }
        }
        while(1) {
            printf("Digite sua altura em cm (ex, 187, 165, 190)\n");
            scanf("%d", &Persons[i][1]);
            if (Persons[i][1] > 0 && Persons[i][1] < 250) {
                break;
            } else {
                printf("Valor inválido.\n");
            }
        }
    }
    for (int i = 4; i >= 0; i--) {
        printf("=== Cadastro %d\n", i+1);
        printf("Idade: %d anos    Altura: %dcm\n", Persons[i][0], Persons[i][1]);
    }
}