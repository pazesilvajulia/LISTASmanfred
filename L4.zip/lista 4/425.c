#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char nomes[50][50], nome[50];

int nome_valido(char * frase) {
    for (int i = 0; i < strlen(frase); i++) {
        if (!isalpha(frase[i]) && frase[i] != ' ') {
            return 0;
        }
    }
    return 1;
} 

int main() {
    // lista de 50 nomes
    for (int j = 0; j < 50; j++) {
        do {
        printf("Nome (%d de 50):  ", j+1);
        fgets(nomes[j], sizeof(nomes[j]), stdin);
    for (int i = 0; i < strlen(nomes[j]); i++) {
        nomes[j][i] = toupper(nomes[j][i]);
    }
    nomes[j][strcspn(nomes[j], "\n")] = '\0';
    
    if (!nome_valido(nomes[j])) {
        printf("Nome inválido. Utilize apenas letras e/ou espaço.\n");
    }
    } while (!nome_valido(nomes[j]));
    }
    // nome a ser comparado
    do {
    printf("Digite seu primeiro nome: ");
    fgets(nome, sizeof(nome), stdin);
    for (int i = 0; nome[i] != '\0'; i++) {
        nome[i] = toupper(nome[i]);
    }
    nome[strcspn(nome, "\n")] = '\0';
    
    if (!nome_valido(nome)) {
        printf("Nome inválido. Utilize apenas letras e/ou espaço.\n");
    }
    } while (!nome_valido(nome));
    
    for (int i = 0; i < 50; i++) {
        if (strcmp(nomes[i], nome) == 0) {
            printf("O nome %s já está na lista.", nome);
            return 0;
        }
    }
    printf("O nome não está na lista.");
}