#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    float media = 0;
    char frase[11];
    int consoantes = 0;
    printf("Insira a frase: ");
    fgets(frase, sizeof(frase), stdin);
    
    for (int i = 0; i < 10; i++) {
        char c = frase[i];
        
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            if (!strchr("AEIOUaeiou", c)) {
            consoantes++;
        }
        }
        
    }
     
 printf("%s\n", frase);
 printf("consoantes: %d", consoantes);
}