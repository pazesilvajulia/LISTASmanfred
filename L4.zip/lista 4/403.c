#include <stdio.h>
#include <stdlib.h>

int main() {
    int n[10];
    for (int i = 9,j = 1; i >= 0; i--, j++) {
        printf("Digite o %dº número:\n", j);
        scanf("%d", &n[i]);
    }
    for (int s = 0; s < 10; s++) {
        printf("- %d\n", n[s]);
    }
}