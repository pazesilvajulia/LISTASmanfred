#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main() {
    float notas[15], media = 0;
    char input_name[50];
    char **nomes = malloc(15 * sizeof(char*)); 
    for (int i = 0; i < 15; i++) {
        // nome
        printf("Digite o nome do aluno %d: ", i+1);
        fgets(input_name, 50, stdin);
        input_name[strcspn(input_name, "\n")] = '\0';
        nomes[i] = malloc(strlen(input_name) + 1);
        strcpy(nomes[i], input_name);
        // nota
        printf("Digite a nota do aluno %d: ", i+1);
        scanf("%f", &notas[i]);
        getchar();
        media += notas[i];
    }
    media = media / 15.0;
    printf("======= média da turma: %.1f", media);
    for (int j = 0; j < 15; j++) {
        printf("====================");
        printf("Aluno: %s\n", nomes[j]);
        printf("Nota: %.1f\n", notas[j]);
        if (notas[j] >= media) {
            printf("NOTA ACIMA DA MÉDIA!");
        } else {
            printf("NOTA ABAIXO DA MÉDIA.");
        }
    }
}