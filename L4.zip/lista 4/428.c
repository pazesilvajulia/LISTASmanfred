#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int frase_com_ponto(char *frase) {
    for (int i = 0; i < (strlen(frase)); i++) {
        if (frase[i] == '.') {return 1;}   
    }
    return 0;
}

int is_palindromo(char *frase) {
    for (int i = 0, j = (strlen(frase) - 1); i < (strlen(frase)); i++, j--) {
        if (frase[i] != frase[j]) {
            return 0;
        }
    }
    return 1;
}

void remove_spaces(char *str) {
    int i = 0;
    int j = 0;

    while (str[i] != '\0') {
        if (str[i] != ' ') {
            str[j] = str[i];
            j++;
        }
        i++;
    }

    str[j] = '\0';
}


int main() {
    char frase[50];
    
    do {
        printf("Digite uma frase de até 50 caracteres com ponto final para descobrir se é um palíndromo ou não. OBS: não use acentos.\n");
        fgets(frase, sizeof(frase) , stdin);
        if (!frase_com_ponto(frase)) {
            printf("texto inválido.\n");
        }
    } while (!frase_com_ponto(frase));
    
    // remover espaço
    
    remove_spaces(frase);
    frase[strcspn(frase, ".")] = '\0';
    
    if (is_palindromo(frase) == 1) {
        printf("É um palíndromo!");
    } else {
        printf("Não é palíndromo.");
    }
}