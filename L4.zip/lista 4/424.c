#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char frase[100];

int nome_valido(char*frase) {
    for (int i = 0; i < strlen(frase); i++) {
        if (!isalpha(frase[i]) && frase[i] != ' ') {
            return 0;
        }
    }
    return 1;
} 

int main() {
    do {
    printf("Digite seu nome (somente letras, use minúsculas e/ou maiúsculas): ");
    fgets(frase, sizeof(frase), stdin);
    frase[strcspn(frase, "\n")] = '\0';
    
    if (!nome_valido(frase)) {
        printf("Nome inválido. Utilize apenas letras e/ou espaço.\n");
    }
    } while (!nome_valido(frase));
    
    int tmn = strlen(frase);
    
    for (int i = 0; i < tmn; i++) {
        frase[i] = toupper(frase[i]);
    }
    
    printf("Frase final em maíusculas E invertido: ");
    for (int j = (tmn - 1); j >= 0; j--) {
        printf("%c", frase[j]);
    }
}