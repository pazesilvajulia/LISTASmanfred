#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int num[20], cpar = 0, cimpar = 0;
    int *par = NULL; 
    int *impar = NULL;
    for (int i = 0; i < 20; i++) {
        printf("Digite o %dº número: ", i+1);
        scanf("%d", &num[i]);
    }
    for (int j = 0; j < 20; j++) {
        if ((num[j] % 2) == 0) {
            cpar++;
            int *temp = realloc(par, cpar * sizeof(int));
            par = temp;
            par[cpar - 1] = num[j];
        } else {
            cimpar++;
            int *temp = realloc(impar, cimpar * sizeof(int));
            impar = temp;
            impar[cimpar - 1] = num[j];
            
        }
    }
    // loop print num
    printf("Todos os números:\n");
    for (int i = 0; i < 20; i++) {
        printf("%d ", num[i]);
    }
    // loop print pares
    printf("\nNúmero pares:\n");
    for (int i = 0; i < cpar; i++) {
        printf("%d ", par[i]);
    }
    // loop print impares
    printf("\nNúmero ímpares:\n");
    for (int i = 0; i < cimpar; i++) {
        printf("%d ", impar[i]);
    }
}