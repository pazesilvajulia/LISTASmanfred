#include <stdio.h>
#include <stdlib.h>

#define TAM1 5
#define TAM2 10
#define TAM_TOTAL (TAM1 + TAM2)

int main() {
    int vetor1[TAM1];
    int vetor2[TAM2];
    int vetor3[TAM_TOTAL];
    int input;
    
    printf("====== PRIMEIRO VETOR\n");
    for (int i = 0; i < TAM1; i++) {
        printf("Digite um número (%d de 5) : ", i+1);
        scanf("%d", &vetor1[i]);
        vetor3[i] = vetor1[i];
    }
    printf("====== SEGUNDO VETOR\n");
    for (int i = 0; i < TAM2; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetor2[i]);
        vetor3[i + TAM1] = vetor2[i];
    } 
    printf("====== TERCEIRO VETOR (V1 + V2)\n");
    for (int i = 0; i < TAM_TOTAL; i++) {
        printf("%d  ", vetor3[i]);
    }
}