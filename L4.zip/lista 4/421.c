#include <stdio.h>
#include <stdlib.h>

#define TAM 10

int main() {
    int vetorA[TAM], vetorB[TAM], vetorC[TAM], vetorD[TAM];
    
    printf("====== VETOR A\n");
    for (int i = 0; i < TAM; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetorA[i]);
    }
    printf("====== VETOR B\n");
    for (int i = 0; i < TAM; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetorB[i]);
    }
    printf("\n====== VETOR C  (A ao quadrado)\n");
    for (int i = 0; i < TAM; i++) {
        vetorC[i] = (vetorA[i] * vetorA[i]);
        printf("%d ", vetorC[i]);
    }
    printf("\n====== VETOR D (A * B)\n");
    for (int i = 0; i < TAM; i++) {
        vetorD[i] = (vetorA[i] * vetorB[i]);
        printf("%d ", vetorD[i]);
    }
}