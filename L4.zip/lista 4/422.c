#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char frase[100];

int main() {
    printf("Digite uma frase: ");
    fgets(frase, sizeof(frase), stdin);
    
    int tamanho_frase = strlen(frase);
    printf("Tamanho: %d", (tamanho_frase - 1));
}