#include <stdio.h>
#include <stdlib.h>

int comparar(const void *a, const void *b) {
    // função precisa de reparo. como estamos usando um vetor[i][2], a função qsort passa a linha inteira MESMO EU TENTANDO PASSAR DIRETAMENTE vetor[i][1]. Portanto, depois disso preciso especificar a coluna que quero dar sort. Além disso, os returns foram invertidos para ordenar de maneira decrescente.
    float *linhaA = (float*)a;
    float *linhaB = (float*)b;
    
    float priceA = linhaA[1];
    float priceB = linhaB[1];
    
    if(priceA > priceB) {return -1;}
    if(priceA < priceB) {return 1;}
    return 0;
}

int main() {
    float prod[30][2];
    
    printf("CADASTRAMENTO DE PRODUTOS\n");
    for (int i = 0; i < 30; i++) {
        printf("Código produto (%d de 30): ", i+1);
        scanf("%f", &prod[i][0]);
        printf("Preço produto (%d de 30): R$ ", i+1);
        scanf("%f", &prod[i][1]);
    }
    
    qsort(prod, 30, sizeof(prod[1]), comparar);
    
    printf("Os 3 produtos mais caros são: ");
    for(int i = 0; i < 3; i++) {
        printf("Produto código nº %.0f - Preço R$%.2f\n", prod[i][0], prod[i][1]);
    }
}