#include <stdio.h>
#include <stdlib.h>

#define TAM1 10
#define TAM2 10
#define TAM_TOTAL (TAM1 + TAM2)

int main() {
    int vetor1[TAM1];
    int vetor2[TAM2];
    int vetor3[TAM_TOTAL];
    int input;
    
    printf("====== PRIMEIRO VETOR\n");
    for (int i = 0; i < TAM1; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetor1[i]);
        vetor3[i] = vetor1[i];
    }
    printf("====== SEGUNDO VETOR\n");
    for (int i = 0; i < TAM2; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetor2[i]);
        vetor3[i + TAM1] = vetor2[i];
    } 
    printf("====== TERCEIRO VETOR (V1 + V2 ALTERNADOS)\n");
    for (int i = 0; i < TAM_TOTAL; i++) {
        if (i % 2 == 0) {
            vetor3[i] = vetor1[i/2];
        } else {
            vetor3[i] = vetor2[i/2];
        }
        printf("%d  ", vetor3[i]);
    }
}