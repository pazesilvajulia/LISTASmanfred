#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char s[] = "A programacao em linguagem C pode ser divertida, educativa e poderosa.";
int blank = 0, vowel = 0;

int main() {
    printf("String analisada: \"%s\"\n", s);
    printf("Total de caracteres: %lu\n", strlen(s));
    
    for (int i = 0; i < strlen(s); i++) {
        char c = tolower(s[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            vowel++;
        } else if (c == ' ') {
            blank++;
        }
    }
    printf("Total de espaços em branco: %d\n", blank);
    printf("Total de vogais: %d", vowel);
}