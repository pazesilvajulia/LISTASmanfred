#include <stdio.h>
#include <stdlib.h>

int main() {
    int n[5], soma = 0, mult = 1;
    for (int i = 0; i < 5; i++) {
        printf("Digite o %dº número:\n", i+1);
        scanf("%d", &n[i]);
    }
    for (int s = 0; s < 5; s++) {
        printf("- %d\n", s);
        soma += n[s];
        mult *= n[s];
    }
    printf("===============\nSoma: %d\nMultiplicação: %d", soma, mult);
}