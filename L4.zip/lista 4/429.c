#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int respostavalida (char input) {
    switch (input) {
        case 'A': return 1;
        case 'B': return 2;
        case 'C': return 3;
        case 'D': return 4;
        case 'E': return 5;
        default:
            printf("Resposta inválida.\n");
            return 0;
    }
}

int main() {
    int gabarito[12], resposta[12], numAlunos = 1;
    char inputChar;
    char input_name[50];
    char **nome_aluno = malloc(numAlunos * sizeof(char*));
    float *nota_aluno = malloc(numAlunos * sizeof(float));
    
    printf("INSIRA O GABARITO DA PROVA: \n");
    printf("A - B - C - D - E\n");
    for (int i = 0; i < 12; i++) {
        int valor;
        do {
        printf("RESPOSTA QUESTÃO %d de 12: \n", i+1);
        scanf(" %c", &inputChar);
        getchar();
        valor = respostavalida(toupper(inputChar));
        } while (!valor);
        gabarito[i] = valor;
    }
    
    // inserir alunos e nota;
    int i = 0;
    while (1) {
        
        printf("Nome do aluno: ");
        fgets(input_name, 50, stdin);
        input_name[strcspn(input_name, "\n")] = '\0';
        nome_aluno[i] = malloc(strlen(input_name) + 1);
        strcpy(nome_aluno[i], input_name);
        // aqui deve ser repetido o codigo do gabarito
        printf("INSIRA O GABARITO DA PROVA: \n");
        printf("A - B - C - D - E\n");
        for (int i = 0; i < 12; i++) {
            int valor;
            do {
                printf("RESPOSTA QUESTÃO %d de 12: \n", i+1);
                scanf(" %c", &inputChar);
                getchar();
                valor = respostavalida(toupper(inputChar));
            } while (!valor);
            resposta[i] = valor;
        }
        // comparando gabarito com resposta para gerar nota
        int acertos = 0;
        for (int j = 0; j < 12; j++) {
            if (gabarito[j] == resposta[j]) {
                acertos++;
            }
        }
        nota_aluno[i] = ((float)acertos / 12) * 10;
        
        // adicionar mais alunos ou finalizar
        int c;
        while(1) {
            printf("Deseja adicionar mais um aluno?\n[1] Sim    [2] Não\n");
            scanf("%d", &c);
            getchar();
            if (c > 0 && c < 3) {
                break;
            } else {
                printf("Resposta inválida. ");
            }
        }
        if (c == 1) {
            i++;
            nome_aluno = realloc(nome_aluno, (i + 1) * sizeof(char*));
            nota_aluno = realloc(nota_aluno, (i + 1)  * sizeof(float));
        } else if (c == 2) {
            break;
        }
    }
    numAlunos = i + 1;
    
    // print gabarito
    printf("GABARITO: \n");
    for (int g = 0; g < 12; g++) {
        printf("%d ", gabarito[g]);
    }
    // print notas alunos
    for (int i = 0; i < numAlunos; i++) {
        printf("=== ALUNO %s\n", nome_aluno[i]);
        printf("Nota: %.1f", nota_aluno[i]);
    }
}