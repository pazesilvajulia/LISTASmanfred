#include <stdio.h>
#include <stdlib.h>

#define TAM1 10
#define TAM2 10
#define TAM3 10
#define TAM_TOTAL 30

int main() {
    int vetor1[TAM1];
    int vetor2[TAM2];
    int vetor3[TAM3];
    int vetor4[TAM1 + TAM2 + TAM3];
    
    printf("====== PRIMEIRO VETOR\n");
    for (int i = 0; i < TAM1; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetor1[i]);
    }
    printf("====== SEGUNDO VETOR\n");
    for (int i = 0; i < TAM2; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetor2[i]);
    }
    printf("====== TERCEIRO VETOR\n");
    for (int i = 0; i < TAM3; i++) {
        printf("Digite um número (%d de 10) : ", i+1);
        scanf("%d", &vetor3[i]);
    }
    printf("====== QUARTO VETOR (v1+ v2 + v3 alternados)\n");
    for (int i = 0; i < TAM1; i++) {     
        vetor4[  i*3      ] = vetor1[i]; 
        vetor4[ (i*3) + 1 ] = vetor2[i];  
        vetor4[ (i*3) + 2 ] = vetor3[i];
    }
    for (int i = 0; i < TAM_TOTAL; i++) {
        printf("%d ", vetor4[i]);
    }
}