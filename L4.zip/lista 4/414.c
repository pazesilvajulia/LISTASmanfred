#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int num[5], n;
    printf("Digite um número: ");
    scanf("%d", &n);
    printf("Agora, digite 5 números.\n");
    for (int i = 0; i < 5; i++) {
        printf("Digite um número (%d de 5): ", i+1);
        scanf("%d", &num[i]);
    }
    printf("Multiplicando o conjunto por %d, temos:\n", n);
    printf("{");
    for (int j = 0; j < 5; j++) {
        printf("  %d", (num[j] * n));
    }
    printf("  }");
}