#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int idades[30], c = 0;
    float input[30], media = 0;
    for (int i = 0; i < 30; i++) {
        printf("ALUNO %d", i+1);
        while(1) {
            printf("- Altura (m): ");
            scanf("%f", &input[i]);
            if (input[i] > 0 && input[i] < 2.5) {
                media += input[i];
                break;
            } else {
                printf("Valor inválido.\n");
            }
        }
        while(1){
            printf("- Idade: ");
            scanf("%d", &idades[i]);
            if (idades[i] > 0 && idades[i] < 120) {
                break;
            } else {
                printf("Valor inválido.\n");
            }
        }
    }
    media = media / 30.0;
    for (int j = 0; j < 5; j++) {
        if (idades[j] < 13 && input[j] < media) {
            c++;
        }
    }
    printf("Total de alunos com 13 anos+ e altura inferior a média: \n%d", c);
}