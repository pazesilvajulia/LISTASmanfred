#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int valores[10], soma = 0;
    for (int i = 0; i < 10; i++) {
        while(1) {
        printf("Insira o %dº número: ", i+1);
        scanf("%d", &valores[i]);
        if (valores[i] > 0) {
            break;
        } else {
            printf("Inválido.\n");
            }
        }
    }
    
    for (int j = 0; j < 10; j++) {
        printf("%d^2 + ", valores[j]);
        soma += valores[j] * valores[j];
        if (j == 9) {
            printf("%d^2 = %d", valores[j], soma);
        }
    }
}