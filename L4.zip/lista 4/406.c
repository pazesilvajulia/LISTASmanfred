#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    
    float mediasturma[10], media;
    float input;
    for (int i = 0; i < 10; i++) { // loop de cada aluno
        printf(" === ALUNO Nº%d\n", i+1);
        media = 0;
        for (int j = 0; j < 4; j++) { // loop de cada nota
            while (1) {
                printf("Nota nº%d: ", j+1);
                scanf("%f", &input);
                if (input < 0 || input > 10) {
                    printf("Erro. Digite uma nota entre 0 e 10.\n");
                } else {
                    break;
                }
            }
            media += input;
        }
    mediasturma[i] = media/4;
    }
    printf("\n\n");
    printf("Médias acima ou iguais a 7:\n");
    for (int m = 0; m < 10; m++) {
        if (mediasturma[m] >= 7) {
            printf("Aluno nº%d: %.1f \n", m+1, mediasturma[m]);
        }
    }
}