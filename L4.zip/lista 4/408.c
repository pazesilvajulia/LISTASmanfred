#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

    int matriculas[10];
    float nota, medias[10], soma;
    
    for (int i = 0; i < 10; i++) {
        soma = 0;
        printf("Cadastro aluno nº%d:\n",i+1);
        while (1) {
            printf("Digite seu nº de matrícula: \n");
            scanf("%d", &matriculas[i]);
            if (matriculas[i] > 0 && matriculas[i] < 99999999) {
                break;
            } else {
                printf("Valor inválido.\n");
            }
        }
        printf("NOTAS ALUNO MATRÍCULA Nº%d\n", matriculas[i]);
        for (int j = 0; j < 4; j++) {
            while(1) {
            printf("Nota nº%d: ", j+1);
            scanf("%f", &nota);
            if (nota < 0 || nota > 10) {
                printf("Valor inválido.\n");
            } else {
                soma += nota;
                break;
                    }
            }
        }
        medias[i] = soma / 4;
}
printf("\n\nRELATÓRIO\n");
for (int m = 0; m < 10; m++) {
    printf("=== Aluno matrícula nº%d\n", matriculas[m]);
    printf("Média: %.2f\n", medias[m]);
}
    
}