#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

    float nota[10], media, soma = 0;
    
    for (int i = 0; i < 10; i++) {
        printf("NOTA ALUNO %d\n", i+1);
        while(1) {
        printf("Nota: ");
        scanf("%f", &nota[i]);
        if (nota >= 0 && nota[i] <= 10) {
            soma += nota[i];
            break;
        }else {
        printf("valor inválido.\n");    
        }
        } 
}
media = soma / 10;
printf("\n\nRELATÓRIO\n");
printf("média da turma: %.1f", media);
printf("Alunos acima da média:\n");
for (int j = 0; j < 10; j++) {
    if (nota[j] >= media) {
        printf("Aluno nº%d, nota: %.1f\n", j+1, nota[j]);
    }
}
}