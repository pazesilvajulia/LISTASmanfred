#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
    int num[20], soma=0;
    
    for (int i = 0; i < 20; i++) {
        printf("Digite um número (%d de 20) : ", i+1);
        scanf("%d", &num[i]);
    }
    
    for (int j = 0; j < 10; j++) {
        int diferenca = num[j] - num[19-j];
        printf("(%d - %d)^2 ", num[j], num[19-j]);
        int termo = pow(diferenca, 2);
        if (j % 2 == 0) {
            soma += termo;
            printf("+ ");
        } else if (j % 2 != 0) {
            if (j < 9) {
                printf("- ");
            }
            soma -= termo;
        }
    }
    printf("= %d", soma);
    return 0;
}