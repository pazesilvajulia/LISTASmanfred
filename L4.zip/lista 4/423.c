#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char frase1[100], frase2[100];

int striguais(char *str1, char *str2) {
    int tmn2 = strlen(str2);
    int tmn1 = strlen(str1);
    if (tmn1 == tmn2) {
        for (int i = 0; i < tmn1; i++) {
            if (str1[i] != str2[i]) {
                return 0;
            }
        }
    } else {
        return 0;
    }
    return 1;
}

int main() {
    printf("Digite uma frase: ");
    fgets(frase1, sizeof(frase1), stdin);
    frase1[strcspn(frase1, "\n")] = '\0';
    printf("Digite mais uma frase: ");
    fgets(frase2, sizeof(frase2), stdin);
    frase2[strcspn(frase2, "\n")] = '\0';
    
    if (striguais(frase1, frase2) == 0) {
        printf("Não são iguais.");
    } else {
        printf("São iguais.");
    }
}