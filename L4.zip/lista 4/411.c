#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int c = 1, input, media = 0;
    int *anos = malloc(sizeof(int));
    while(1) {
        while(1) {
            printf("Ano de nascimento pessoa nº1: ");
            scanf("%d", &anos[c-1]);
            if (anos[c-1] <= 2025) {
                media += anos[c-1];
                break;
            } else {
                printf("Ano inválido.\n");
            }
        }
        while(1){
            printf("Adicionar mais algum cadastro?\n");
            printf("[1] Sim, continuar\n[2] Não, finalizar\n");
            scanf("%d", &input);
            if (input < 3 && input > 0) {
                break;
            } else {
                printf("Erro.\n");
            }
        }
        if (input == 1) {
            c++;
            anos = realloc(anos, c * sizeof(int));
        } else {
            break;
        }
        
    }
    media = (2025 - (media / c));
    printf("Media do grupo: %d\n", media);
    for (int j = 0; j < c; j++) {
        printf("- Nº%d   nascimento:%d    idade: %d anos.\n",j+1, anos[j], (2025 - anos[j]));
    }